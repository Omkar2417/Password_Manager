import React, { useRef, useState, useEffect } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { v4 as uuidv4 } from "uuid";

const Manager = () => {
  const siteRef = useRef();
  const usernameRef = useRef();
  const passwordRef = useRef();

  const [form, setForm] = useState({ site: "", username: "", password: "" });
  const [passwordArray, setPasswordArray] = useState([]);
  const [editId, setEditId] = useState(null); // State to track editing

  useEffect(() => {
    const passwords = localStorage.getItem("passwords");
    if (passwords) {
      setPasswordArray(JSON.parse(passwords));
    }
  }, []);

  const copyText = (text) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        toast.success("Text Copied to clipboard!", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        });
      })
      .catch((err) => {
        console.error("Could not copy text: ", err);
      });
  };

  const showPassword = () => {
    passwordRef.current.type = passwordRef.current.type === "text" ? "password" : "text";
  };

  const savePassword = () => {
    const { site, username, password } = form;
    if (!site || !username || !password) {
      toast.warn("Please fill out all the fields!", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    const updatedPasswordArray = [
      ...passwordArray,
      { ...form, id: uuidv4() },
    ];
    setPasswordArray(updatedPasswordArray);
    localStorage.setItem("passwords", JSON.stringify(updatedPasswordArray));
    setForm({ site: "", username: "", password: "" });
    toast.success("Added Successfully!", {
      position: "top-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "colored",
    });
  };

  const deletePassword = (id) => {
    const ConfirmToast = ({ closeToast }) => (
      <div>
        <p>Do you really want to delete this password?</p>
        <button
          onClick={() => {
            const updatedPasswordArray = passwordArray.filter(
              (password) => password.id !== id
            );
            setPasswordArray(updatedPasswordArray);
            localStorage.setItem("passwords", JSON.stringify(updatedPasswordArray));
            toast.success("Deleted Successfully!", {
              position: "top-center",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "colored",
            });
            closeToast();
          }}
          className="bg-red-500 text-white px-2 py-1 rounded"
        >
          Yes
        </button>
        <button
          onClick={closeToast}
          className="bg-gray-500 text-white px-2 py-1 rounded ml-2"
        >
          No
        </button>
      </div>
    );

    toast(ConfirmToast, {
      position: "top-center",
      autoClose: false,
      closeOnClick: false,
      draggable: false,
    });
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const editData = (id, newSite, newUsername, newPassword) => {
    const updatedPasswordArray = passwordArray.map((password) => {
      if (password.id === id) {
        return {
          ...password,
          site: newSite,
          username: newUsername,
          password: newPassword,
        };
      }
      return password;
    });

    setPasswordArray(updatedPasswordArray);
    localStorage.setItem("passwords", JSON.stringify(updatedPasswordArray));

    toast.success("Updated Successfully!", {
      position: "top-center",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "colored",
    });
  };

  const handleEdit = (password) => {
    setForm({
      site: password.site,
      username: password.username,
      password: password.password,
    });
    setEditId(password.id);
  };

  const handleSaveEdit = () => {
    editData(editId, form.site, form.username, form.password);
    setForm({ site: "", username: "", password: "" });
    setEditId(null);
  };

  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
      />
      <div className="absolute top-0 z-[-2] h-screen w-screen rotate-180 transform bg-green-100 bg-[radial-gradient(60%_120%_at_50%_50%,hsla(0,0%,100%,0)_0,rgba(252,205,238,.5)_100%)]"></div>
      <div className="container mx-auto max-w-screen-lg p-4 min-h-[83.5vh]">
        
        <h1 className="text-4xl font-bold text-center mb-4">
          <span className="text-green-700">&lt;</span>
          Keep
          <span className="text-green-700">IT</span>
          Safe
          <span className="text-green-700">/&gt;</span>
        </h1>
        <p className="text-green-800 font-semibold text-center mt-2 flex items-center justify-center">
          Unleash the Power of Your Own&nbsp;
          <span className="text-red-700 font-extrabold font-serif underline hover:text-purple-600 transition duration-300 ease-in-out">
            Password
          </span>
          <lord-icon
            src="https://cdn.lordicon.com/stxfyhky.json"
            trigger="hover"
            className="w-6 h-6 ml-1"
          ></lord-icon>
          &nbsp;Manager
        </p>
        <div className="flex flex-col p-4 text-black gap-8 items-center">
          <input
            ref={siteRef}
            value={form.site}
            onChange={handleChange}
            className="rounded-full border border-green-500 w-full px-4 py-1"
            type="text"
            name="site"
            placeholder="Website/Application"
          />
          <div className="flex flex-col sm:flex-row w-full justify-between gap-4">
            <input
              ref={usernameRef}
              value={form.username}
              onChange={handleChange}
              className="rounded-full border border-green-500 w-full px-4 py-1"
              type="text"
              name="username"
              placeholder="Username"
            />
            <div className="relative w-full">
              <input
                ref={passwordRef}
                value={form.password}
                onChange={handleChange}
                className="rounded-full border border-green-500 w-full px-4 py-1"
                type="password"
                name="password"
                placeholder="Password"
              />
              <span
                className="absolute right-[3px] cursor-pointer top-1/2 transform -translate-y-1/2 mt-1"
                onClick={showPassword}
              >
                <lord-icon
                  className="om"
                  src="https://cdn.lordicon.com/ccrgnftl.json"
                  trigger="hover"
                  colors="primary:#3a3347,secondary:#4bb3fd,tertiary:#f9c9c0,quaternary:#f24c00,quinary:#8930e8"
                ></lord-icon>
              </span>
            </div>
          </div>
          {editId ? (
            <button
              className="flex justify-center items-center bg-purple-300 hover:bg-green-500 rounded-full px-4 py-2 w-full sm:w-auto border-2 border-black cursor-pointer"
              style={{ transition: "all 0.2s ease-in-out" }}
              onClick={handleSaveEdit}
            >
              <lord-icon
                src="https://cdn.lordicon.com/jgnvfzqg.json"
                trigger="hover"
              ></lord-icon>
              Save Edit
            </button>
          ) : (
            <button
              className="flex justify-center items-center bg-purple-300 hover:bg-green-500 rounded-full px-4 py-2 w-full sm:w-auto border-2 border-black cursor-pointer"
              style={{ transition: "all 0.2s ease-in-out" }}
              onClick={savePassword}
            >
              <lord-icon
                src="https://cdn.lordicon.com/jgnvfzqg.json"
                trigger="hover"
              ></lord-icon>
              Save
            </button>
          )}
        </div>
        <div className="password mt-8">
          <h1 className="text-red-700 font-serif font-extrabold text-3xl text-left mb-4">
            Your Passwords
          </h1>
          {passwordArray.length === 0 && <div className="text-purple-800">No Password to show...!</div>}
          {passwordArray.length !== 0 && (
            <div>
              <table className="table-auto w-full">
                <thead className="bg-green-800 text-white border-2 border-green-700">
                  <tr>
                    <th>Site</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {passwordArray.map((password) => (
                    <tr key={password.id} className="odd:bg-white even:bg-gray-100">
                      <td className="text-center py-2 border-2 border-green-700">
                        <div className="flex items-center justify-center">
                          <span>{password.site}</span>
                          <div
                            className="lordiconcopy cursor-pointer"
                            onClick={() => copyText(password.site)}
                          >
                            <lord-icon
                              src="https://cdn.lordicon.com/yqiuuheo.json"
                              trigger="hover"
                              colors="primary:#c7c116,secondary:#8930e8"
                            ></lord-icon>
                          </div>
                        </div>
                      </td>
                      <td className="text-center py-2 border-2 border-green-700">
                        <div className="flex items-center justify-center">
                          <span>{password.username}</span>
                          <div
                            className="lordiconcopy cursor-pointer"
                            onClick={() => copyText(password.username)}
                          >
                            <lord-icon
                              src="https://cdn.lordicon.com/yqiuuheo.json"
                              trigger="hover"
                              colors="primary:#c7c116,secondary:#8930e8"
                            ></lord-icon>
                          </div>
                        </div>
                      </td>
                      <td className="text-center py-2 border-2 border-green-700">
                        <div className="flex items-center justify-center">
                          <span>{password.password}</span>
                          <div
                            className="lordiconcopy cursor-pointer"
                            onClick={() => copyText(password.password)}
                          >
                            <lord-icon
                              src="https://cdn.lordicon.com/yqiuuheo.json"
                              trigger="hover"
                              colors="primary:#c7c116,secondary:#8930e8"
                            ></lord-icon>
                          </div>
                        </div>
                      </td>
                      <td className="text-center py-2 border-2 border-green-700">
                        <span
                          className="cursor-pointer"
                          onClick={() => handleEdit(password)}
                        >
                          <lord-icon
                            src="https://cdn.lordicon.com/vhyuhmbl.json"
                            trigger="hover"
                            colors="primary:#8930e8,secondary:#ffc738,tertiary:#3a3347"
                          ></lord-icon>
                        </span>
                        <span
                          className="cursor-pointer"
                          onClick={() => deletePassword(password.id)}
                        >
                          <lord-icon
                            src="https://cdn.lordicon.com/hjbrplwk.json"
                            trigger="hover"
                            colors="primary:#646e78,secondary:#4bb3fd,tertiary:#8930e8,quaternary:#3a3347"
                          ></lord-icon>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Manager;
